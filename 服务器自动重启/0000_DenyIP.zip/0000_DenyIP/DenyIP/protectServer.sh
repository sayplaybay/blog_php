#!/bin/sh
serverIP=`/sbin/ifconfig|grep 'inet addr:'|head -n 1|cut -d: -f2|awk '{print $1}'`
result=`curl http://$serverIP/zhuzhaoning/protectServer.zzn`
echo $result>/opt/lampp/htdocs/0000_DenyIP/DenyIP/status.log
if [ "$result" != "Server is running" ];then
	echo `date "+%Y-%m-%d %H:%M:%S"`>>/opt/lampp/htdocs/0000_DenyIP/DenyIP/restart.log
	eval "/opt/lampp/lampp restartapache;"
fi
