<?php
set_time_limit(0);


$cronrule = "*/10 * * * * /opt/lampp/htdocs/0000_DenyIP/DenyIP/protectServer.sh >/dev/null 2>&1";

$rsylog = file_get_contents("/etc/rsyslog.d/50-default.conf");
$rsylog = preg_replace("/#cron.*?\/var\/log\/cron.log/","cron.*			/var/log/cron.log",$rsylog);
file_put_contents("/etc/rsyslog.d/50-default.conf",$rsylog);

if(is_file("/var/spool/cron/crontabs/root")){
	$crontasks = file_get_contents("/var/spool/cron/crontabs/root");
	preg_match('/.*?\/opt\/lampp\/htdocs\/0000_DenyIP\/DenyIP\/0000_DenyIP\/DenyIP\/protectServer\.sh.*/',$crontasks,$match);
	if(isset($match[0])&&trim($match[0])==$cronrule) die("cron task is right");
		
	$crontasks = preg_replace('/.*?\/opt\/lampp\/htdocs\/0000_DenyIP\/DenyIP\/protectServer\.sh.*/','',$crontasks);
	$crontasks = preg_replace("/^[\s\r\n\t]+$/s",'', $crontasks);
	$crontasks .= $cronrule.PHP_EOL;
	file_put_contents("/var/spool/cron/crontabs/root",$crontasks);
		
}else{
	file_put_contents("/var/spool/cron/crontabs/root",$cronrule.PHP_EOL);
}
?>